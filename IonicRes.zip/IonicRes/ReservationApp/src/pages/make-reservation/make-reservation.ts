import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Reservation } from '../../models/reservation';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'page-make-reservation',
  templateUrl: 'make-reservation.html'
})
export class MakeReservationPage {

  reservation: Reservation;
  salutations: string[];
  submitted = false;

  constructor(public navCtrl: NavController) {
    this.salutations = ['Mr.','Ms.','Mrs.','Mdm.','Dr.'];
    this.reservation = new Reservation("Mr.","Tan","98765432",2,3,new Date().toISOString(), new Date().toISOString());
  }

  get testing(){
    return JSON.stringify(this.reservation);
  }
  
  onSubmit(form: NgForm){

      this.submitted = true;

      if(form.valid && this.reservation.noOfAdults >= 1){

      alert('Reservation created:'
      + "\n Salutation: " + this.reservation.salutation
      + "\n Name: " + this.reservation.name
      + "\n Mobile No: " + this.reservation.mobileNo
      + "\n No. of Adults: " + this.reservation.noOfAdults
      + "\n No. of Children: " + this.reservation.noOfChildren
      + "\n Date: " + this.reservation.date
      + "\n Time: " + this.reservation.time
      )
    }
  }

}
