import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Reservation } from '../../models/reservation';
import { ReservationDetailsPage } from '../reservation-details/reservation-details';


@Component({
  selector: 'page-view-reservations',
  templateUrl: 'view-reservations.html'
})
export class ViewReservationsPage implements OnInit {

  reservations: Reservation[];
  //reservation: Reservation;

  constructor(public navCtrl: NavController, private navParams: NavParams) {
    
  }

  ngOnInit(){

    this.reservations = [
      new Reservation("Mr.", "Clint Barton", "99998888",2,3,"4/6/2018","1930"),
      new Reservation("Mrs.", "Laura Barton", "99997777",2,0,"8/6/2018","2000"),
      new Reservation("Dr.", "Bruce Banner", "99996666",2,0,"9/6/2018","1930"),
      new Reservation("Ms.", "Natasha Romanova", "99995555",2,0,"10/6/2018","2000")
    ];

  }

  goToReservationDetails(params){
    if(!params) params={};
    this.navCtrl.push(ReservationDetailsPage,params);
  }
  
}
