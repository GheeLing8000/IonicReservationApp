import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Reservation } from '../../models/reservation';

@Component({
  selector: 'page-reservation-details',
  templateUrl: 'reservation-details.html'
})
export class ReservationDetailsPage {

  reservation: Reservation;

  constructor(public navCtrl: NavController, private navParams: NavParams) {

    let salutation = navParams.get('salutation');
    let name = navParams.get('name');
    let mobileNo = navParams.get('mobileNo');
    let noOfAdults = navParams.get('noOfAdults');
    let noOfChildren = navParams.get('noOfChildren');
    let date = navParams.get('date');
    let time = navParams.get('time');
    this.reservation = new Reservation(salutation, name, mobileNo, noOfAdults, noOfChildren, date, time);


  }
  
}
