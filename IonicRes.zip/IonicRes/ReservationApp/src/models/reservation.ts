export class Reservation{

    constructor(
        public salutation: string,
        public name: string,
        public mobileNo: string,
        public noOfAdults: number,
        public noOfChildren: number,
        public date: string,
        public time: string
    ){}

}